//const ipamnetwork = require('../models').ipamnetwork;

module.exports = (sequelize, DataTypes) => {
  const ipamip = sequelize.define('ipamip', {
    network: {type: DataTypes.STRING, allowNull: false,},
    ip: {type: DataTypes.STRING, allowNull: false,},
    exclude: {type: DataTypes.BOOLEAN, defaultValue: false},
    hostname: {type: DataTypes.STRING}
  },
  {
    freezeTableName: true,
    timestamps: false
  });
  ipamip.removeAttribute('id');

  ipamip.associate = (models) => {
  ipamip.belongsTo(models.ipamnetwork, {
      foreignKey: 'network',
      onDelete: 'CASCADE',
    });
  };    
  return ipamip;
};


// 'use strict';
// const {
//   Model
// } = require('sequelize');
// module.exports = (sequelize, DataTypes) => {
//   class ipamip extends Model {
//     /**
//      * Helper method for defining associations.
//      * This method is not a part of Sequelize lifecycle.
//      * The `models/index` file will call this method automatically.
//      */
//     static associate(models) {
//       // define association here
//     }
//   };
//   ipamip.init({
//     network: DataTypes.STRING,
//     ip: DataTypes.STRING,
//     exclude: DataTypes.BOOLEAN,
//     hostname: DataTypes.STRING
//   }, {
//     sequelize,
//     modelName: 'ipamip',
//   });
//   return ipamip;
// };