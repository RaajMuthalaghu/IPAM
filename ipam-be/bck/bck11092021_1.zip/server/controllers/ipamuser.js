const ipamuser = require('../models').ipamuser;
//const ipamuser = require('../models/ipamuser')(sequelize, DataTypes);

module.exports = {
  list(req, res) {
    return ipamuser
      .findAll()
      .then(ipamuser => res.status(200).send(ipamuser))
      .catch(error => res.status(400).send(error));
  },
  create(req, res) {
    return ipamuser
      .create({
        username: req.body.username,
        password: req.body.password,
        admintype: req.body.admintype,
      })
      .then(ipamuser => res.status(201).send(ipamuser.username + " User created Successfully!"))
      .catch(error => res.status(400).send(error));
  },
};

