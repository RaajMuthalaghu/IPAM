const ipamnetwork = require('../models').ipamnetwork;
//const ipamip = require('../models').ipamip;

module.exports = {
  list(req, res) {
    return ipamnetwork
//      .findAll()
      .findAll({
        include: [{
          model: ipamip,
          as: 'ipamip',
        }],
      })  
      .then(ipamnetwork => res.status(200).send(ipamnetwork))
      .catch(error => res.status(400).send(error));
  },
  create(req, res) {
    return ipamnetwork
      .create({
        network: req.body.network,
        vlan: req.body.vlan,
        subnet: req.body.subnet,
        netmask: req.body.netmask,
        gateway: req.body.gateway,
        fromip: req.body.fromip,
        toip: req.body.toip
      })
      .then(ipamnetwork => res.status(201).send(ipamnetwork.network + " Network created Successfully!"))
      .catch(error => res.status(400).send(error));
  },
};
