const ipamip = require('../models').ipamip;

module.exports = {
  list(req, res) {
    return ipamip
      .findAll()
      .then(ipamip => res.status(200).send(ipamip))
      .catch(error => res.status(400).send(error));
  },
  create(req, res) {
    return ipamip
      .create({
        network: req.body.network,
        ip: req.body.ip,
        exclude: req.body.exclude,
        hostname: req.body.hostname
      })
      .then(ipamip => res.status(201).send(ipamip.ip + " added into " + ipamip.network + " Network Successfully!"))
      .catch(error => res.status(400).send(error));
  },
};
