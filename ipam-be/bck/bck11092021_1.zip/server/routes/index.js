const ipamuserController = require('../controllers').ipamuser;
const ipamnetworkController = require('../controllers').ipamnetwork;
const ipamipController = require('../controllers').ipamip;

module.exports = (app) => {
  // app.get('/users', (req, res) => res.status(200).send({message: 'Welcome to the ipamuser API!',}));
  app.get('/users', ipamuserController.list);
  app.post('/users', ipamuserController.create);

  app.get('/networks', ipamnetworkController.list);
  app.post('/networks', ipamnetworkController.create);

  app.get('/ips', ipamipController.list);
  app.post('/ips', ipamipController.create);
};
