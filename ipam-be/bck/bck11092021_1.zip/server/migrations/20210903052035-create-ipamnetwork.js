module.exports = {
  up:  (queryInterface, Sequelize) => 
     queryInterface.createTable('ipamnetwork', {
      network: {
        allowNull: false,
        primaryKey: true,
        type: Sequelize.STRING
      },
      vlan: {
        allowNull: false,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      subnet: {
        allowNull: false,
        primaryKey: true,
        type: Sequelize.STRING
      },
      netmask: {
        allowNull: false,
        primaryKey: true,
        type: Sequelize.STRING
      },
      gateway: {
        allowNull: false,
        primaryKey: true,
        type: Sequelize.STRING
      },
      fromip: {
        type: Sequelize.STRING
      },
      toip: {
        type: Sequelize.STRING
      }
    }),
    down: (queryInterface, Sequelize) => queryInterface.dropTable('ipamnetwork'),
  };