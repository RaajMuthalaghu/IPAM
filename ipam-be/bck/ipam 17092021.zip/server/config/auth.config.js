module.exports = {
    secret: "citiuscloud"
  };
  