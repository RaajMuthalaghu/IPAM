const ipamuser = require('./ipamuser');
const ipamnetwork = require('./ipamnetwork');
const ipamip = require('./ipamip');

module.exports = {
    ipamuser,
    ipamnetwork,
    ipamip,
};
