const Pool = require('pg').Pool
const pool = new Pool({host: "localhost", user: "admin", database: "ipam", password: "admin", port: "5432"})

const authenticate = (req, res) => {
  try{
    // const username = req.params.username
    // const password = req.params.password
    const { username, password } = req.body;
    pool.query('SELECT * FROM ipamUser WHERE username = $1', [username], (error, results) => {
    if (results.rows.length) {
      if (results.rows[0].password == password)
        res.status(200).send({ "message": "User Authenticated" });
      else
        res.status(400).send({ "message": "Wrong Password" });
    }
    else{
      res.status(400).send({ "message": "No User found" });
    }
    })
  }catch (error) {res.status(404).send({ message: error.message, error: error });}
};

const getAllusers = (req, res) => {
  try{
      pool.query('SELECT * FROM ipamUser ORDER BY username ASC', (error, results) => {
      res.status(200).json(results.rows)
    })
  }catch (error) {res.status(404).send({ message: error.message, error: error });}
};

const getuserByName = (req, res) => {
  const username = req.params.username
  try{
    pool.query('SELECT * FROM ipamUser WHERE username = $1', [username], (error, results) => {
    res.status(200).json(results.rows)
    })
  }catch (error) {res.status(404).send({ message: error.message, error: error });}
};

const adduser =  (req, res) => {
  const { username, password, admintype } = req.body;
  try{
      pool.query('INSERT INTO ipamUser (username, password, admintype) VALUES ($1, $2, $3)', [username, password, admintype], (error, results) => {
      res.status(201).send(`User added with username: ${username}`)
    })
  }catch (error) {res.status(404).send({ message: error.message, error: error });}
};

const updateuser = (req, res) => {
  const username = req.params.username
  const { password, admintype } = req.body;
  try{
  if(password){
      pool.query('UPDATE ipamUser SET password = $2 WHERE username = $1', [username, password], (error, results) => {
        res.status(200).send(`Pssword updated for Username: ${username}`)
      })
    }else{
        pool.query('UPDATE ipamUser SET admintype = $2 WHERE username = $1', [username, admintype], (error, results) => {
          res.status(200).send(`Access modified for Username: ${username}`)
        })
    }
  }catch (error) {res.status(404).send({ message: error.message, error: error });}
};

const deleteuser = (req, res) => {
const username = req.params.username
  try{
    pool.query('DELETE FROM ipamUser WHERE username = $1', [username], (error, results) => {
      res.status(200).send(`User deleted  with Username: ${username}`)
    })
  }catch (error) {res.status(404).send({ message: error.message, error: error });}
};

module.exports = {
  authenticate,
  getAllusers,
  getuserByName,
  adduser,
  updateuser,
  deleteuser
};
