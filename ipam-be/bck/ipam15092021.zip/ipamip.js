const Pool = require('pg').Pool
const pool = new Pool({host: "localhost", user: "admin", database: "ipam", password: "admin", port: "5432"})

const getipsByNetwork = (req, res) => {
  const network = req.params.network
  try{
    pool.query('SELECT * FROM ipamIP WHERE network = $1', [network], (error, results) => {
    res.status(200).json(results.rows)
    })
  }catch (error) {res.status(404).send({ message: error.message, error: error });}
};

const getfreeipsByNetwork = (req, res) => {
  const network = req.params.network
  try{
    pool.query('SELECT * FROM ipamIP WHERE network = $1 and exclude=False and hostname IS NULL', [network], (error, results) => {
    res.status(200).json(results.rows)
    })
  }catch (error) {res.status(404).send({ message: error.message, error: error });}
};

const getusedipsByNetwork = (req, res) => {
  const network = req.params.network
  try{
    pool.query('SELECT * FROM ipamIP WHERE network = $1 and exclude=False and hostname IS NOT NULL', [network], (error, results) => {
    res.status(200).json(results.rows)
    })
  }catch (error) {res.status(404).send({ message: error.message, error: error });}
};

const addips =  (req, res) => {
  const { network, ip, exclude } = req.body;
  try{
      pool.query('INSERT INTO ipamIP (network, ip, exclude) VALUES ($1, $2, $3)', [network, ip, exclude], (error, results) => {
      res.status(201).send(`Network  IPs added: ${network}`)
    })
  }catch (error) {res.status(404).send({ message: error.message, error: error });}
};

const updateips = (req, res) => {
  const ip = req.params.ip
  const { exclude, hostname } = req.body;
  try{
    pool.query('UPDATE ipamIP SET exclude = $2, hostname = $3 WHERE ip = $1', 
        [ip, exclude, hostname], (error, results) => {
    res.status(200).send(`Network  IPs updated for: ${ip}`)
    })
  }catch (error) {res.status(404).send({ message: error.message, error: error });}
};

const deleteips = (req, res) => {
const network = req.params.network
  try{
    pool.query('DELETE FROM ipamIP WHERE network = $1', [network], (error, results) => {
      res.status(200).send(`Network IPs deleted : ${network}`)
    })
  }catch (error) {res.status(404).send({ message: error.message, error: error });}
};

module.exports = {
    getipsByNetwork,
    getfreeipsByNetwork,
    getusedipsByNetwork,
    addips,
    updateips,
    deleteips
};
