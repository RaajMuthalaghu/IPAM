const express = require('express');
const bodyParser = require('body-parser');
// const user = require('./ipamusers');
// const network = require('./ipamnetwork');
// const ip = require('./ipamip');

const app = express();
const port = 5000;

app.use(express.json());
app.use(bodyParser.urlencoded({ extended: true, }))

const db = require("./server/models");
db.sequelize.sync({ force: false }).then(() => {
    console.log("Drop and re-sync db.");
});

// Require our routes into the application.
require('./server/routes')(app);
app.get('*', (req, res) => res.status(200).send({message: 'CitiusCloud IPAM Application',}));
/*
app.get('/', (req, res) => {  res.json({ info: 'CitiusCloud IPAM Application' })})
//-------------ipamUser 
app.get('/users/', user.getAllusers);
app.get('/users/:username', user.getuserByName);
app.post('/users/authenticate', user.authenticate);
app.post('/users/', user.adduser);
app.put('/users/:username', user.updateuser);
app.delete('/users/:username', user.deleteuser);

//--------------ipamNetwork
app.get('/networks/', network.getAllnetworks);
app.get('/networks/:network', network.getnetworkByName);
//app.get('/networks/:vlan', network.getnetworkByvlan);
app.post('/networks/', network.addnetwork);
app.put('/networks/:network', network.updatenetwork);
app.delete('/networks/:network', network.deletenetwork);


//--------------ipamIP
app.get('/ips/:network', ip.getipsByNetwork);
app.get('/freeips/:network', ip.getfreeipsByNetwork);
app.get('/usedips/:network', ip.getusedipsByNetwork);
app.post('/ips/', ip.addips);
app.put('/ips/:ip', ip.updateips);
app.delete('/ips/:network', ip.deleteips);
*/

app.listen(port, () => {console.log(`CitiusCloud's IPAM app is running on port ${port}.`);});
module.exports = app;