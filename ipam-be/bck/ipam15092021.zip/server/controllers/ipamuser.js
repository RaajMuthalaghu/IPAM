const ipamuser = require('../models').ipamuser;
//const ipamuser = require('../models/ipamuser')(sequelize, DataTypes);

module.exports = {
  authenticate(req, res) {
    ipamuser
    .findAll({ where: {username: req.body.username,}, })
    .then(ipamuser => {
      if (!ipamuser) { res.status(404).send({ message: 'Username Not Found', }); }
      if (ipamuser[0].password != req.body.password) { res.status(404).send({ message: 'Password does Not Match', }); }
      return res.status(200).send({ "message": "User Authenticated" });
    })
   .catch((error) => res.status(400).send(error));
 },

  list(req, res) {
    return ipamuser
      .findAll()
      .then(ipamuser => res.status(200).send(ipamuser))
      .catch(error => res.status(400).send(error));
  },
  create(req, res) {
    return ipamuser
      .create({
        username: req.body.username,
        password: req.body.password,
        admintype: req.body.admintype,
      })
      .then(ipamuser => res.status(201).send(ipamuser.username + " User created Successfully!"))
      .catch(error => res.status(400).send(error));
  },
  retrieve(req, res) {
    return ipamuser
        .findAll({ where: {username: req.params.username,}, })
    .then(ipamuser => {
      if (!ipamuser) {
        res.status(404).send({
          message: 'Username Not Found',
        });
      }
      return res.status(200).send(ipamuser);
    })
    .catch(error => res.status(400).send(error));
  },
  update(req, res) {
    ipamuser
     .update({
      password: req.body.password || ipamuser.password,
      admintype: req.body.admintype || ipamuser.admintype,
     }, {where: { username: req.params.username, }}
     )
//      .then(() => res.status(200).send(ipamuser))  // Send back the updated ipamuser.
     .then(() => res.status(200).send({"updated": req.params.username}))  // Send back the updated ipamuser.
     .catch((error) => res.status(400).send(error));
 },
 destroy(req, res) {
  return ipamuser
    .destroy({where: { username: req.params.username, }})
    .then(() => res.status(200).send({"status":"success"}))  // Send back the updated ipamuser.
    .catch((error) => res.status(400).send(error));
},
};

