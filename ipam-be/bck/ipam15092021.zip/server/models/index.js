const Sequelize = require("sequelize");
const env = process.env.NODE_ENV || 'development';
const config = require(`${__dirname}/../config/config.json`)[env];

const sequelize = new Sequelize(config.database, config.username, config.password, {
  host: config.host,
  dialect: config.dialect,
  operatorsAliases: false,

  pool: {
    max: config.pool.max,
    min: config.pool.min,
    acquire: config.pool.acquire,
    idle: config.pool.idle
  }
});

const db = {};

db.Sequelize = Sequelize;
db.sequelize = sequelize;

db.ipamuser = require("./ipamuser.js")(sequelize, Sequelize);
db.ipamnetwork = require("./ipamnetwork.js")(sequelize, Sequelize);
db.ipamip = require("./ipamip.js")(sequelize, Sequelize);
db.ipamip.belongsTo(db.ipamnetwork, {
  foreignKey: 'network',
  onDelete: 'CASCADE',
});
db.ipamnetwork.hasMany(db.ipamip, {
  foreignKey: 'network',
});


module.exports = db;

