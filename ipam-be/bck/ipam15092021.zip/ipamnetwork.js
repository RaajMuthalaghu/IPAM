const Pool = require('pg').Pool
const pool = new Pool({host: "localhost", user: "admin", database: "ipam", password: "admin", port: "5432"})

const getAllnetworks = (req, res) => {
  try{
      pool.query('SELECT * FROM ipamNetwork ORDER BY network ASC', (error, results) => {
      res.status(200).json(results.rows)
    })
  }catch (error) {res.status(404).send({ message: error.message, error: error });}
};

const getnetworkByName = (req, res) => {
  const network = req.params.network
  try{
    pool.query('SELECT * FROM ipamNetwork WHERE network = $1', [network], (error, results) => {
    res.status(200).json(results.rows)
    })
  }catch (error) {res.status(404).send({ message: error.message, error: error });}
};

const getnetworkByvlan = (req, res) => {
  const vlan = req.params.vlan
  try{
    pool.query('SELECT * FROM ipamNetwork WHERE vlan = $1', [vlan], (error, results) => {
    res.status(200).json(results.rows)
    })
  }catch (error) {res.status(404).send({ message: error.message, error: error });}
};

const addnetwork =  (req, res) => {
  const { network, vlan, subnet, netmask, gateway, fromIP, toIP } = req.body;
  try{
      pool.query('INSERT INTO ipamNetwork (network, vlan, subnet, netmask, gateway, fromIP, toIP) VALUES ($1, $2, $3,$4,$5,$6,$7)', [network, vlan, subnet, netmask, gateway, fromIP, toIP], (error, results) => {
      res.status(201).send(`Network added: ${network}`)
    })
  }catch (error) {res.status(404).send({ message: error.message, error: error });}
};

const updatenetwork = (req, res) => {
  const network = req.params.network
  const { vlan, subnet, netmask, gateway, fromIP, toIP } = req.body;
  try{
    pool.query('UPDATE ipamNetwork SET vlan = $2, subnet = $3, netmask = $4, gateway = $5, fromIP = $6, toIP = $7 WHERE network = $1', 
        [network, vlan, subnet, netmask, gateway, fromIP, toIP], (error, results) => {
    res.status(200).send(`Network updated for: ${network}`)
    })
  }catch (error) {res.status(404).send({ message: error.message, error: error });}
};

const deletenetwork = (req, res) => {
const network = req.params.network
  try{
    pool.query('DELETE FROM ipamNetwork WHERE network = $1', [network], (error, results) => {
      res.status(200).send(`Network deleted : ${network}`)
    })
  }catch (error) {res.status(404).send({ message: error.message, error: error });}
};

module.exports = {
  getAllnetworks,
  getnetworkByName,
  getnetworkByvlan,
  addnetwork,
  updatenetwork,
  deletenetwork
};
