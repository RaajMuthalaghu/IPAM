import React, { Component } from "react";
import UserDataService from "../services/user.service";

export default class AddUser extends Component {
  constructor(props) {
    super(props);
    this.onChangeusername = this.onChangeusername.bind(this);
    this.onChangepassword = this.onChangepassword.bind(this);
    this.onChangeadmintype = this.onChangeadmintype.bind(this);
    this.saveUser = this.saveUser.bind(this);
    this.newUser = this.newUser.bind(this);

    this.state = {
      username: "",
      password: "", 
      admintype: false,

      submitted: false
    };
  }

  onChangeusername(e) {
    this.setState({
        username: e.target.value
    });
  }

  onChangepassword(e) {
    this.setState({
        password: e.target.value
    });
  }

  onChangeadmintype(e) {
    this.setState({
        admintype: e.target.value
    });
  }

  saveUser() {
    var data = {
      username: this.state.username,
      password: this.state.password,
      admintype: this.state.admintype
    };

    UserDataService.create(data)
      .then(response => {
        this.setState({
            username: response.data.username,
            password: response.data.password,
            admintype: response.data.admintype,

            submitted: true
        });
        console.log(response.data);
      })
      .catch(e => {
        console.log(e);
      });
  }

  newUser() {
    this.setState({
        username: "",
        password: "",
        admintype: false,

        submitted: false
    });
  }

  render() {
    return (
        <div className="submit-form">
          {/* {this.state.submitted ? (
            <div>
              <h4>Request submitted successfully!</h4>
              <button className="btn btn-success" onClick={this.newUser}>
                Add
              </button>
            </div>
          ) : ( */}
            <div>
              <div className="form-group">
                <label htmlFor="username">Username</label>
                <input
                  type="text"
                  className="form-control"
                  id="username"
                  required
                  value={this.state.username}
                  onChange={this.onChangeusername}
                  name="username"
                />
              </div>
  
              <div className="form-group">
                <label htmlFor="password">Password</label>
                <input
                  type="password"
                  className="form-control"
                  id="password"
                  required
                  value={this.state.password}
                  onChange={this.onChangepassword}
                  name="password"
                />
              </div>
  
              <div className="form-group">
                <label htmlFor="admintype">Is Admin</label>
                <input
                  type="text"
                  className="form-control"
                  id="admintype"
                  required
                  value={this.state.admintype}
                  onChange={this.onChangeadmintype}
                  name="admintype"
                />
              </div>
  
              <button onClick={this.saveUser} className="btn btn-success">
                Submit
              </button>
            </div>
          {/* )} */}
        </div>
      );
  }
}