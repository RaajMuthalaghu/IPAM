import React, { Component } from "react";
//import UserDataService from "../services/user.service";
import { connect } from "react-redux";
import { createNetwork } from "../actions/networks";
import { toaster } from "../utils/toast";

class AddNetwork extends Component {
  constructor(props) {
    super(props);
    this.onChangenetwork = this.onChangenetwork.bind(this);
    this.onChangevlan = this.onChangevlan.bind(this);
    this.onChangesubnet = this.onChangesubnet.bind(this);
    this.onChangenetmask = this.onChangenetmask.bind(this);
    this.onChangegateway = this.onChangegateway.bind(this);
    this.onChangefromip = this.onChangefromip.bind(this);
    this.onChangetoip = this.onChangetoip.bind(this);
    this.saveNetwork = this.saveNetwork.bind(this);
    this.newNetwork = this.newNetwork.bind(this);

    this.state = {
      network: "",
      vlan: 0, 
      subnet: "",
      netmask: "",
      gateway: "",
      fromip: "",
      toip: "",

      submitted: false
    };
  }

  onChangenetwork(e) {
    this.setState({
        network: e.target.value
    });
  }

  onChangevlan(e) {
    this.setState({
        vlan: e.target.value
    });
  }

  onChangesubnet(e) {
    this.setState({
        subnet: e.target.value
    });
  }

  onChangenetmask(e) {
    this.setState({
      netmask: e.target.value
    });
  }

  onChangegateway(e) {
    this.setState({
        gateway: e.target.value
    });
  }
  onChangefromip(e) {
    this.setState({
      fromip: e.target.value
    });
  }


  onChangetoip(e) {
    this.setState({
      toip: e.target.value
    });
  }

  saveNetwork() {
    const { network, vlan, subnet, netmask, gateway, fromip, toip } = this.state;
    this.props
    .createNetwork(network, vlan, subnet, netmask, gateway, fromip, toip)
    .then((data) => {
      this.setState({
        network: data.network,
        vlan: data.vlan,
        subnet: data.subnet,
        netmask: data.netmask,
        gateway: data.gateway,
        fromip: data.fromip,
        toip: data.toip,

        submitted: true,
      });
      console.log(data);
      toaster(data,"info");
            
    })
    .catch((e) => {
      console.log(e);
    });
  }

  newNetwork() {
    this.setState({
        network: "",
        vlan: 0, 
        subnet: "",
        netmask: "",
        gateway: "",
        fromip: "",
        toip: "",

        submitted: false
    });
  }

  render() {
    return (

        <div className="submit-form">
          <form>
          {this.state.submitted ? (
            <div>
              <h4>Request submitted successfully!</h4>
              <button className="btn btn-success" onClick={this.newNetwork}>
                Add Network
              </button>
            </div>
          ) : (
            <div>
              <div className="form-group">
                <label htmlFor="network">Network</label>
                <input
                  type="text"
                  className="form-control"
                  id="network"
                  required
                  value={this.state.network}
                  onChange={this.onChangenetwork}
                  name="network"
                />
              </div>
  
              <div className="form-group">
                <label htmlFor="vlan">Vlan</label>
                <input
                  type="integer"
                  className="form-control"
                  id="vlan"
                  required
                  value={this.state.vlan}
                  onChange={this.onChangevlan}
                  name="vlan"
                />
              </div>
              <div className="form-group">
                <label htmlFor="subnet">Subnet</label>
                <input
                  type="text"
                  className="form-control"
                  id="subnet"
                  required
                  value={this.state.subnet}
                  onChange={this.onChangesubnet}
                  name="subnet"
                />
              </div>
              <div className="form-group">
                <label htmlFor="netmask">Netmask</label>
                <input
                  type="text"
                  className="form-control"
                  id="netmask"
                  required
                  value={this.state.netmask}
                  onChange={this.onChangenetmask}
                  name="netmask"
                />
              </div>
              <div className="form-group">
                <label htmlFor="gateway">Gateway</label>
                <input
                  type="text"
                  className="form-control"
                  id="gateway"
                  required
                  value={this.state.gateway}
                  onChange={this.onChangegateway}
                  name="gateway"
                />
              </div>
              <div className="form-group">
                <label htmlFor="fromip">Fromip</label>
                <input
                  type="text"
                  className="form-control"
                  id="fromip"
                  required
                  value={this.state.fromip}
                  onChange={this.onChangefromip}
                  name="fromip"
                />
              </div>
              <div className="form-group">
                <label htmlFor="toip">Toip</label>
                <input
                  type="text"
                  className="form-control"
                  id="toip"
                  required
                  value={this.state.toip}
                  onChange={this.onChangetoip}
                  name="toip"
                />
              </div>
    
              <button onClick={this.saveNetwork} className="btn btn-success">
                Submit
              </button>
              <button onClick={(e) => { e.preventDefault(); window.location.href="/networks/"; }} className="btn btn-success">
                Cancel
              </button>

            </div>
           )} 
          </form>

        </div>
      );
  }
}
export default connect(null, { createNetwork })(AddNetwork);