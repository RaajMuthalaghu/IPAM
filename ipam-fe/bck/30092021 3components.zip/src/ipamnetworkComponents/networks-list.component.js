import React, { useState, useEffect, useMemo, useRef } from "react";
import NetworkDataService from "../services/network.service";
import { useTable } from "react-table";
import { Link } from "react-router-dom";

const NetworksList = (props) => {
  const [networks, setNetworks] = useState([]);
  const [searchNetwork, setSearchNetwork] = useState("");
  const networksRef = useRef();

  networksRef.current = networks;

  useEffect(() => {
    retrieveNetworks();
    
  }, []);

  const onChangeSearchNetwork = (e) => {
    const searchNetwork = e.target.value;
    setSearchNetwork(searchNetwork);
  };

  const retrieveNetworks = () => {
    NetworkDataService.getAll()
      .then((response) => {
        setNetworks(response.data);
      })
      .catch((e) => {
        console.log(e);
      });
  };

  const refreshList = () => {
    retrieveNetworks();
  };

  // const removeAllNetworks = () => {
  //   NetworkDataService.removeAll()
  //     .then((response) => {
  //       console.log(response.data);
  //       refreshList();
  //     })
  //     .catch((e) => {
  //       console.log(e);
  //     });
  // };

  const findByNetwork = () => {
    NetworkDataService.findByNetwork(searchNetwork)
      .then((response) => {
        var x =[]; x.push(response.data);
        setNetworks(x);
      })
      .catch((e) => {
        console.log(e);
      });
  };

  const openNetwork = (rowIndex) => {
    const network = networksRef.current[rowIndex].network;
    props.history.push("/networks/" + network);
  };

  const deleteNetwork = (rowIndex) => {
    const network = networksRef.current[rowIndex].network;

    NetworkDataService.delete(network)
      .then((response) => {
        props.history.push("/networks");

        let newNetworks = [...networksRef.current];
        newNetworks.splice(rowIndex, 1);

        setNetworks(newNetworks);
      })
      .catch((e) => {
        console.log(e);
      });
  };

  const columns = useMemo(
    () => [
      { Header: "Network", accessor: "network", },
      { Header: "Vlan", accessor: "vlan", },
      { Header: "Subnet", accessor: "subnet", },
      { Header: "Netmask", accessor: "netmask", },
      { Header: "Gateway", accessor: "gateway", },
      { Header: "FromIP", accessor: "fromip", },
      { Header: "ToIP", accessor: "toip", },
      { Header: "Actions", accessor: "actions",
      Cell: (props) => {
          const rowIdx = props.row.id;
          return (
            <div>
              <span onClick={() => openNetwork(rowIdx)}>
                <i className="far fa-edit action mr-2"></i>
              </span>

              <span onClick={() => deleteNetwork(rowIdx)}>
                <i className="fas fa-trash action"></i>
              </span>
            </div>
          );
        },
      },
    ],
    []
  );

  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    rows,
    prepareRow,
  } = useTable({
    columns,
    data: networks,
  });

  return (
    <div className="list row">
      <div className="col-md-8">
        <div className="input-group mb-3">
          <input
            type="text"
            className="form-control"
            placeholder="Search by network"
            value={searchNetwork}
            onChange={onChangeSearchNetwork}
          />
          <div className="input-group-append">
            <button
              className="btn btn-outline-secondary"
              type="button"
              onClick={findByNetwork}
            >
              Search
            </button>
          </div>
        </div>
      </div>
      <div className="col-md-12 list">
        <table
          className="table table-striped table-bordered"
          {...getTableProps()}
        >
          <thead>
            {headerGroups.map((headerGroup) => (
              <tr {...headerGroup.getHeaderGroupProps()}>
                {headerGroup.headers.map((column) => (
                  <th {...column.getHeaderProps()}>
                    {column.render("Header")}
                  </th>
                ))}
              </tr>
            ))}
          </thead>
          <tbody {...getTableBodyProps()}>
            {rows.map((row, i) => {
              prepareRow(row);
              return (
                <tr {...row.getRowProps()}>
                  {row.cells.map((cell) => {
                    return (
                      <td {...cell.getCellProps()}>{cell.render("Cell")}</td>
                    );
                  })}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <div className="col-md-8">
        {/* <button className="btn btn-sm btn-danger" onClick={removeAllNetworks}>
          Add Network
        </button> */}
        <Link to={"/addnetwork"} className="nav-link"> Add Networks </Link>
      </div>
    </div>
  );
};

export default NetworksList;
