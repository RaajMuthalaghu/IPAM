import http from "../http-common";

class UserDataService {
  getAll() {
    return http.get("/users");
  }

  get(username) {
    return http.get(`/users/${username}`);
  }

  create(data) {
    return http.post("/auth/signup", data);
  }

  updatePassword(username, data) {
    return http.put(`/users/updatepassword/${username}`, data);
  }

  toggleadmintype(username, data) {
    return http.put(`/users/toggleadmintype/${username}`, data);
  }

  delete(username) {
    return http.delete(`/users/${username}`);
  }

//   deleteAll() {
//     return http.delete(`/users`);
//   }

  findByUserName(username) {
    return http.get(`/users/${username}`);
  }
}

export default new UserDataService();