import React, { useState, useEffect, useMemo, useRef } from "react";
import IPDataService from "../services/ip.service";
import { useTable } from "react-table";

const IPList = (props) => {
  const [ips, setips] = useState([]);
  const [searchip, setSearchip] = useState("");
  const ipsRef = useRef();

  ipsRef.current = ips;

  useEffect(() => {
    retrieveips(props.match.params.network);
    
  }, [props.match.params.network]);

  const onChangeSearchip = (e) => {
    const searchip = e.target.value;
    setSearchip(searchip);
  };

  const retrieveips = (network) => {
    IPDataService.get(network)
      .then((response) => {
        setips(response.data);
      })
      .catch((e) => {
        console.log(e);
      });
  };

  const refreshList = () => {
    retrieveips(props.match.params.network);
  };

  // const removeAllNetworks = () => {
  //   IPDataService.removeAll()
  //     .then((response) => {
  //       console.log(response.data);
  //       refreshList();
  //     })
  //     .catch((e) => {
  //       console.log(e);
  //     });
  // };

  const findByip = () => {
    IPDataService.findByip(searchip)
      .then((response) => {
        var x =[]; x.push(response.data);
        setips(x);
      })
      .catch((e) => {
        console.log(e);
      });
  };

  const openIP = (rowIndex) => {
    //const network = ipsRef.current[rowIndex].network;
    const ip = ipsRef.current[rowIndex].ip;
    //props.history.push("/ips/" + network + "/" + ip);
    props.history.push("/ip/" + ip);
  };

//   const deleteNetwork = (rowIndex) => {
//     const network = networksRef.current[rowIndex].network;

//     IPDataService.delete(network)
//       .then((response) => {
//         props.history.push("/networks");

//         let newNetworks = [...networksRef.current];
//         newNetworks.splice(rowIndex, 1);

//         setNetworks(newNetworks);
//       })
//       .catch((e) => {
//         console.log(e);
//       });
//   };

  const columns = useMemo(
    () => [
      { Header: "Network", accessor: "network", },
      { Header: "IP", accessor: "ip", },
//      { Header: "Exclude", accessor: "exclude", },
      { Header: "Exclude", accessor: "exclude", Cell: (props) => { return props.value ? "true" : "false"; },},
      { Header: "Hostname", accessor: "hostname", },
      { Header: "Actions", accessor: "actions",
      Cell: (props) => {
          const rowIdx = props.row.id;
          return (
            <div>
              <span onClick={() => openIP(rowIdx)}>
                <i className="far fa-edit action mr-2"></i>
              </span>

              {/* <span onClick={() => deleteNetwork(rowIdx)}>
                <i className="fas fa-trash action"></i>
              </span> */}
            </div>
          );
        },
      },
    ],
    []
  );

  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    rows,
    prepareRow,
  } = useTable({
    columns,
    data: ips,
  });

  return (
    <div className="list row">
      <div className="col-md-8">
        <div className="input-group mb-3">
          <input
            type="text"
            className="form-control"
            placeholder="Search by IP"
            value={searchip}
            onChange={onChangeSearchip}
          />
          <div className="input-group-append">
            <button
              className="btn btn-outline-secondary"
              type="button"
              onClick={findByip}
            >
              Search
            </button>
          </div>
        </div>
      </div>
      <div className="col-md-12 list">
        <table
          className="table table-striped table-bordered"
          {...getTableProps()}
        >
          <thead>
            {headerGroups.map((headerGroup) => (
              <tr {...headerGroup.getHeaderGroupProps()}>
                {headerGroup.headers.map((column) => (
                  <th {...column.getHeaderProps()}>
                    {column.render("Header")}
                  </th>
                ))}
              </tr>
            ))}
          </thead>
          <tbody {...getTableBodyProps()}>
            {rows.map((row, i) => {
              prepareRow(row);
              return (
                <tr {...row.getRowProps()}>
                  {row.cells.map((cell) => {
                    return (
                      <td {...cell.getCellProps()}>{cell.render("Cell")}</td>
                    );
                  })}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* <div className="col-md-8">
        <button className="btn btn-sm btn-danger" onClick={removeAllNetworks}>
          Add Network
        </button>
        <Link to={"/addnetwork"} className="nav-link"> Add Networks </Link>
      </div> */}
    </div>
  );
};

export default IPList;
