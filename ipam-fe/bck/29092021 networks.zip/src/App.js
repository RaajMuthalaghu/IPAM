import React, { Component } from "react";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import "@fortawesome/fontawesome-free/css/all.css";
import "@fortawesome/fontawesome-free/js/all.js";
import "./App.css";

import Login from "./components/login"
import AddUser from "./components/add-user.component";
import User from "./components/user.component";
import UsersList from "./components/users-list.component";

import AddNetwork from "./ipamnetworkComponents/add-network.component";
import Network from "./ipamnetworkComponents/network.component";
import NetworksList from "./ipamnetworkComponents/networks-list.component";


class App extends Component {
  render() {
    return (
      <Router>
        <nav className="navbar navbar-expand navbar-dark bg-dark">
          <div className="navbar-brand">
            CitiusCloud IPAM
          </div>
          {/* <div className="navbar-nav mr-auto">
            <li className="nav-item">
              <Link to={"/users"} className="nav-link">
                Users
              </Link>
            </li>
            <li className="nav-item">
              <Link to={"/auth/signup"} className="nav-link">
                Add
              </Link>
            </li>
          </div> */}
        </nav>

        <div className="container mt-3">
          <Switch>
            <Route exact path={["/","/auth/signin"]} component={Login} />
            <Route exact path="/users" component={UsersList} />
            <Route exact path="/auth/signup" component={AddUser} />
            <Route path="/users/:username" component={User} />

            <Route exact path="/networks" component={NetworksList} />
            <Route exact path="/addnetwork" component={AddNetwork} />
            <Route path="/networks/:network" component={Network} />
          </Switch>
        </div>
      </Router>
    );
  }
}

export default App;